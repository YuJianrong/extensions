const script = document.createElement('script');
// script.src = 'http://localhost:3000/nihonbungeisha.js';
script.src = 'https://yujianrong.github.io/extensions/nihonbungeisha.js';
script.async = false;
script.onload = () => script.remove();

document.documentElement.prepend(script);
