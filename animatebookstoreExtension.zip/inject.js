const req = new XMLHttpRequest();
req.addEventListener('load', ({ target }) => {
  const script = document.createElement('script');
  script.textContent = target.responseText;
  script.onload = () => script.remove();
  document.documentElement.prepend(script);
});
req.open('GET', 'https://yujianrong.github.io/extensions/animatebookstore.js', false);
req.send();

chrome.runtime.onMessage.addListener((request) => window.postMessage(request));
