const script = document.createElement('script');
script.src = 'https://yujianrong.github.io/extensions/comicdays.js';
script.async = false;
script.onload = () => script.remove();

document.documentElement.prepend(script);
chrome.runtime.onMessage.addListener((request) => window.postMessage(request));
