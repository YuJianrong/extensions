'use strict';

chrome.webRequest.onBeforeRequest.addListener(
  (details) =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-start',
    }),
  { urls: ['https://cdn-img.comic-days.com/public/page/*'] },
);
chrome.webRequest.onErrorOccurred.addListener(
  (details) =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-end',
      success: false,
    }),
  { urls: ['https://cdn-img.comic-days.com/public/page/*'] },
);
chrome.webRequest.onCompleted.addListener(
  (details) =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-end',
      success: true,
    }),
  { urls: ['https://cdn-img.comic-days.com/public/page/*'] },
);

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    details.responseHeaders.push(
      { name: 'Access-Control-Allow-Origin', value: '*' },
      { name: 'Access-Control-Allow-Methods', value: '*' },
    );
    return { responseHeaders: details.responseHeaders };
  },
  // filters
  { urls: ['https://cdn-img.comic-days.com/public/page/*'] },
  // extraInfoSpec
  ['blocking', 'responseHeaders', 'extraHeaders'],
);
