const script = document.createElement('script');
// script.src = 'http://localhost:3000/ganma.js';
script.src = 'https://yujianrong.github.io/extensions/ganma.js';
script.async = false;
script.onload = () => script.remove();
document.documentElement.prepend(script);

chrome.runtime.onMessage.addListener((request) => window.postMessage(request));
