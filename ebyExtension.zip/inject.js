const script = document.createElement('script');
// script.src = 'http://localhost:5000/eby.js';
script.src = 'https://yujianrong.github.io/extensions/eby.js';
script.async = false;
script.onload = () => script.remove();
if (location.pathname.startsWith('/viewer')) {
  const url = new URL(location.href);
  url.pathname = url.pathname.replace('/viewer', '/bviewer');
  location.href = url.toString();
}

document.documentElement.prepend(script);
