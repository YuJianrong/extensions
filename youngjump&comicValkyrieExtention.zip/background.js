'use strict';

chrome.webRequest.onBeforeRequest.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-start'
    }),
  {
    urls: [
      'https://www.youngjump.world/books/*/img/pages/*',
      'https://www.comic-valkyrie.com/samplebook/*/data/*.jpg'
    ]
  }
);
chrome.webRequest.onErrorOccurred.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-end',
      success: false
    }),
  {
    urls: [
      'https://www.youngjump.world/books/*/img/pages/*',
      'https://www.comic-valkyrie.com/samplebook/*/data/*.jpg'
    ]
  }
);
chrome.webRequest.onCompleted.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-end',
      success: true
    }),
  {
    urls: [
      'https://www.youngjump.world/books/*/img/pages/*',
      'https://www.comic-valkyrie.com/samplebook/*/data/*.jpg'
    ]
  }
);

// chrome.webRequest.onHeadersReceived.addListener(
//   details => {
//     details.responseHeaders.push(
//       { name: 'Access-Control-Allow-Origin', value: '*' },
//       { name: 'Access-Control-Allow-Methods', value: '*' }
//     );
//     return { responseHeaders: details.responseHeaders };
//   },
//   // filters
//   { urls: ['https://www.youngjump.world/*'] },
//   // extraInfoSpec
//   ['blocking', 'responseHeaders', 'extraHeaders']
// );
