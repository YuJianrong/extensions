const script = document.createElement('script');
script.src = 'https://yujianrong.github.io/extensions/shogakukan.js';
script.async = false;
script.onload = () => script.remove();

document.documentElement.prepend(script);
script.remove();

const scriptRatioOverride = document.createElement('script');
scriptRatioOverride.textContent = 'window.devicePixelRatio = 2;';
document.documentElement.appendChild(scriptRatioOverride);
scriptRatioOverride.remove();
