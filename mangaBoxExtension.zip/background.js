'use strict';

const urls = ['https://www.mangabox.me/api/*/image*'];

function createHandler(msg) {
  return (details) =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      ...msg,
    });
}

chrome.webRequest.onBeforeRequest.addListener(createHandler({ type: 'request-start' }), { urls });
chrome.webRequest.onErrorOccurred.addListener(
  createHandler({ type: 'request-end', success: false }),
  { urls },
);
chrome.webRequest.onCompleted.addListener(createHandler({ type: 'request-end', success: true }), {
  urls,
});

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const newHeaders = details.responseHeaders
      .filter(({ name }) => !/^Access-Control-Allow/i.test(name))
      .filter(({ name }) => !/^Content-Security-Policy/i.test(name));

    const corsHeaders = [
      { name: 'Access-Control-Allow-Credentials', value: 'true' },
      { name: 'Access-Control-Allow-Methods', value: '*' },
    ];

    // 只有拿得到来源时才加 ACAO，且避免 undefined
    const origin = details.initiator || details.originUrl;
    if (origin) {
      corsHeaders.push({
        name: 'Access-Control-Allow-Origin',
        value: origin,
      });
    }

    return { responseHeaders: [...newHeaders, ...corsHeaders] };
  },
  // filters
  { urls },
  // extraInfoSpec
  ['blocking', 'responseHeaders', 'extraHeaders'],
);
