'use strict';

chrome.webRequest.onBeforeRequest.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-start'
    }),
  { urls: ['https://storage.comic-earthstar.jp/*'] }
);
chrome.webRequest.onErrorOccurred.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-end',
      success: false
    }),
  { urls: ['https://storage.comic-earthstar.jp/*'] }
);
chrome.webRequest.onCompleted.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-end',
      success: true
    }),
  { urls: ['https://storage.comic-earthstar.jp/*'] }
);

chrome.webRequest.onHeadersReceived.addListener(
  details => {
    if (!details.responseHeaders.find(header => header.name === 'access-control-allow-origin')) {
      details.responseHeaders.push({ name: 'access-control-allow-origin', value: '*' });
    }
    if (!details.responseHeaders.find(header => header.name === 'access-control-allow-methods')) {
      details.responseHeaders.push({ name: 'access-control-allow-methods', value: '*' });
    }
    return { responseHeaders: details.responseHeaders };
  },
  // filters
  { urls: ['https://storage.comic-earthstar.jp/*'] },
  // extraInfoSpec
  ['blocking', 'responseHeaders', 'extraHeaders']
);
