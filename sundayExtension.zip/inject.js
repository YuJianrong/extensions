const script = document.createElement('script');
// script.src = 'http://localhost:5000/sunday.js';
script.src = 'https://yujianrong.github.io/extensions/sunday.js';
script.async = false;
script.onload = () => script.remove();

document.documentElement.prepend(script);
