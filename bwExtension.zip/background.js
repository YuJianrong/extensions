'use strict';

chrome.webRequest.onBeforeRequest.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-start',
    }),
  { urls: ['https://bw-bv-epubs.bookwalker.jp/e_product/*'] },
);
chrome.webRequest.onErrorOccurred.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-end',
      success: false,
    }),
  { urls: ['https://bw-bv-epubs.bookwalker.jp/e_product/*'] },
);
chrome.webRequest.onCompleted.addListener(
  details =>
    details.tabId >= 0 &&
    chrome.tabs.sendMessage(details.tabId, {
      from: 'd-tool',
      requestId: details.requestId,
      type: 'request-end',
      success: true,
    }),
  { urls: ['https://bw-bv-epubs.bookwalker.jp/e_product/*'] },
);
