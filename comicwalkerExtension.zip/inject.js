const script = document.createElement('script');
script.src = 'https://yujianrong.github.io/extensions/comicwalker.js';
script.async = false;
script.onload = () => script.remove();

document.documentElement.prepend(script);
