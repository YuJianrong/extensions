const script = document.createElement('script');
script.src = 'https://yujianrong.github.io/extensions/coronaEx.js';
script.async = false;
script.onload = () => script.remove();

document.documentElement.prepend(script);
