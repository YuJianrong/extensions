'use strict';

function sendMessage(imgUrl, tabId, requestId, type, others = {}) {
  if (tabId >= 0) {
    chrome.tabs.sendMessage(tabId, {
      from: 'd-tool',
      requestId,
      type,
      ...others
    });
  }
}

chrome.webRequest.onBeforeRequest.addListener(
  ({ url, tabId, requestId }) => sendMessage(url, tabId, requestId, 'request-start'),
  {
    urls: ['https://play.dl.dlsite.com/content/work/books/*.jpg*']
  }
);
chrome.webRequest.onErrorOccurred.addListener(
  ({ url, tabId, requestId }) =>
    sendMessage(url, tabId, requestId, 'request-end', { success: false }),
  {
    urls: ['https://play.dl.dlsite.com/content/work/books/*.jpg*']
  }
);
chrome.webRequest.onCompleted.addListener(
  ({ url, tabId, requestId }) =>
    sendMessage(url, tabId, requestId, 'request-end', { success: true }),
  {
    urls: ['https://play.dl.dlsite.com/content/work/books/*.jpg*']
  }
);

// chrome.webRequest.onHeadersReceived.addListener(
//   details => {
//     details.responseHeaders.push(
//       { name: 'Access-Control-Allow-Origin', value: '*' },
//       { name: 'Access-Control-Allow-Methods', value: '*' }
//     );
//     return { responseHeaders: details.responseHeaders };
//   },
//   // filters
//   { urls: ['https://www.youngjump.world/*'] },
//   // extraInfoSpec
//   ['blocking', 'responseHeaders', 'extraHeaders']
// );
