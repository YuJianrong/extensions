'use strict';

function sendMessage(imgUrl, tabId, requestId, type, others = {}) {
  if (tabId >= 0) {
    chrome.tabs.sendMessage(tabId, {
      from: 'd-tool',
      requestId,
      type,
      ...others,
    });
  } else {
    chrome.tabs.query({ url: 'https://futabanet.jp/common/*' }, tabs =>
      tabs
        .filter(({ url }) => imgUrl.startsWith(url))
        .forEach(({ id }) =>
          chrome.tabs.sendMessage(id, {
            from: 'd-tool',
            requestId,
            type,
            ...others,
          }),
        ),
    );
  }
}

chrome.webRequest.onBeforeRequest.addListener(
  ({ url, tabId, requestId }) => sendMessage(url, tabId, requestId, 'request-start'),
  {
    urls: [
      'https://www.youngjump.world/books/*/img/pages/*',
      'https://www.comic-valkyrie.com/samplebook/*/data/*.jpg',
      'https://gammaplus.takeshobo.co.jp/manga/*.jpg',
      'https://comic-meteor.jp/ptdata/*.jpg',
      'http://comicride.jp/viewer/*.jpg',
      'https://r.binb.jp/epm/*.jpg',
      'http://comicride.jp/viewer/*.jpg',
      'https://*.cloudfront.net/*',
      'https://futabanet.jp/common/*',
      'https://static.ichijinsha.co.jp/online/books/*.jpg',
      'https://comic-polaris.jp/ptdata/*.jpg',
      'https://*.sslcs.cdngc.net/*/sbcGetImg.php*',
    ],
  },
);
chrome.webRequest.onErrorOccurred.addListener(
  ({ url, tabId, requestId }) =>
    sendMessage(url, tabId, requestId, 'request-end', { success: false }),
  {
    urls: [
      'https://www.youngjump.world/books/*/img/pages/*',
      'https://www.comic-valkyrie.com/samplebook/*/data/*.jpg',
      'https://gammaplus.takeshobo.co.jp/manga/*.jpg',
      'https://comic-meteor.jp/ptdata/*.jpg',
      'http://comicride.jp/viewer/*.jpg',
      'https://r.binb.jp/epm/*.jpg',
      'http://comicride.jp/viewer/*.jpg',
      'https://*.cloudfront.net/*',
      'https://futabanet.jp/common/*',
      'https://static.ichijinsha.co.jp/online/books/*.jpg',
      'https://comic-polaris.jp/ptdata/*.jpg',
      'https://*.sslcs.cdngc.net/*/sbcGetImg.php*',
    ],
  },
);
chrome.webRequest.onCompleted.addListener(
  ({ url, tabId, requestId }) =>
    sendMessage(url, tabId, requestId, 'request-end', { success: true }),
  {
    urls: [
      'https://www.youngjump.world/books/*/img/pages/*',
      'https://www.comic-valkyrie.com/samplebook/*/data/*.jpg',
      'https://gammaplus.takeshobo.co.jp/manga/*.jpg',
      'https://comic-meteor.jp/ptdata/*.jpg',
      'http://comicride.jp/viewer/*.jpg',
      'https://r.binb.jp/epm/*.jpg',
      'http://comicride.jp/viewer/*.jpg',
      'https://*.cloudfront.net/*',
      'https://futabanet.jp/common/*',
      'https://static.ichijinsha.co.jp/online/books/*.jpg',
      'https://comic-polaris.jp/ptdata/*.jpg',
      'https://*.sslcs.cdngc.net/*/sbcGetImg.php*',
    ],
  },
);

// chrome.webRequest.onHeadersReceived.addListener(
//   details => {
//     details.responseHeaders.push(
//       { name: 'Access-Control-Allow-Origin', value: '*' },
//       { name: 'Access-Control-Allow-Methods', value: '*' }
//     );
//     return { responseHeaders: details.responseHeaders };
//   },
//   // filters
//   { urls: ['https://www.youngjump.world/*'] },
//   // extraInfoSpec
//   ['blocking', 'responseHeaders', 'extraHeaders']
// );
